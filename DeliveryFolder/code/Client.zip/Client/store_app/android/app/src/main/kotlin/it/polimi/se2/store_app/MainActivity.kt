package it.polimi.se2.store_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
