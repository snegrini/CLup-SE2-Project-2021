import 'package:flutter/painting.dart';

class ClupColors {
  static const Color grapefruit = Color(0xFFDA4026);
  static const Color disabledGrapefruit = Color(0xFFFF956F);
}