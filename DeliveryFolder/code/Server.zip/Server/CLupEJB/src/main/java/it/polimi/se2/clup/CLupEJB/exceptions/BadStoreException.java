package it.polimi.se2.clup.CLupEJB.exceptions;

public class BadStoreException extends Exception {
    private static final long serialVersionUID = 1L;

    public BadStoreException(String message) {
        super(message);
    }
}
