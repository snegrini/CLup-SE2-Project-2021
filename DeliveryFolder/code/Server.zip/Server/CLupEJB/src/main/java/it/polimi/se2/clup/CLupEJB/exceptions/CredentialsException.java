package it.polimi.se2.clup.CLupEJB.exceptions;

public class CredentialsException extends Exception {
    private static final long serialVersionUID = 1L;

    public CredentialsException(String message) {
        super(message);
    }
}

