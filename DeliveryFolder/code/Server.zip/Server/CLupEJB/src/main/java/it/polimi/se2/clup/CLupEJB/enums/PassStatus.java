package it.polimi.se2.clup.CLupEJB.enums;

public enum PassStatus {
    VALID, USED, EXPIRED
}
