package it.polimi.se2.clup.CLupEJB.enums;

public enum UserRole {
    ADMIN, MANAGER, EMPLOYEE
}
