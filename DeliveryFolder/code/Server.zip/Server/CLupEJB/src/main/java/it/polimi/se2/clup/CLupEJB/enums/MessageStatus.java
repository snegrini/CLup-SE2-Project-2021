package it.polimi.se2.clup.CLupEJB.enums;

public enum MessageStatus {
    OK, ERROR
}
