package it.polimi.se2.clup.CLupEJB.exceptions;

public class TokenException extends Exception {
    public TokenException(String message) {
        super(message);
    }
}
